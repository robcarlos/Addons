local Env = select(2, ...)

-- Client / expansion detection
-- Retail Classic clients define WOW_PROJECT_ID and friends.
-- Warmane WotLK 3.3.5a (and many older clients) do NOT, so we fall back to interface number from GetBuildInfo().
local projectID = _G.WOW_PROJECT_ID

if type(projectID) == "number" then
    Env.IS_CLASSIC_ERA = projectID == _G.WOW_PROJECT_CLASSIC
    Env.IS_CLASSIC_WRATH = projectID == _G.WOW_PROJECT_WRATH_CLASSIC
    Env.IS_CLASSIC_CATA = projectID == _G.WOW_PROJECT_CATACLYSM_CLASSIC
    Env.IS_CLASSIC_MISTS = projectID == _G.WOW_PROJECT_MISTS_CLASSIC
else
    local interface = select(4, GetBuildInfo())
    interface = tonumber(interface) or 0
    -- 1.13.x  -> 11300
    -- 3.3.5a  -> 30300
    -- 4.3.4   -> 40300/40400-ish (depends on client)
    Env.IS_CLASSIC_ERA = interface >= 11000 and interface < 20000
    Env.IS_CLASSIC_WRATH = interface >= 30000 and interface < 40000
    Env.IS_CLASSIC_CATA = interface >= 40000 and interface < 50000
    Env.IS_CLASSIC_MISTS = interface >= 50000 and interface < 60000
end

-- Season of Discovery (Classic Era only)
Env.IS_CLASSIC_ERA_SOD = false
if Env.IS_CLASSIC_ERA and _G.C_Engraving and _G.C_Engraving.IsEngravingEnabled then
    Env.IS_CLASSIC_ERA_SOD = C_Engraving.IsEngravingEnabled()
end

Env.IS_CLIENT_SUPPORTED = Env.IS_CLASSIC_ERA or Env.IS_CLASSIC_ERA_SOD or Env.IS_CLASSIC_WRATH or Env.IS_CLASSIC_CATA or Env.IS_CLASSIC_MISTS

if _G.C_AddOns and C_AddOns.GetAddOnMetadata then
    Env.VERSION = C_AddOns.GetAddOnMetadata(select(1, ...), "Version")
    Env.AUTHORS = C_AddOns.GetAddOnMetadata(select(1, ...), "Author")
else
    Env.VERSION = GetAddOnMetadata(select(1, ...), "Version")
    Env.AUTHORS = GetAddOnMetadata(select(1, ...), "Author")
end

-- Some private clients (3.3.5a) do not expose GetMaxPlayerLevel()
if not _G.GetMaxPlayerLevel then
    function GetMaxPlayerLevel() return 80 end
end

Env.supportedClientNames = {
    "Classic: Mists of Pandaria",
    "Classic: Cataclysm",
    "Classic: WotLK",
    "Classic: SoD",
    "Classic: Era/Anniversary",
}

-- SkillLine.db2
local professionSkillLineIDs = {
    Blacksmithing  = 164,
    Leatherworking = 165,
    Alchemy        = 171,
    Herbalism      = 182,
    Mining         = 186,
    Tailoring      = 197,
    Engineering    = 202,
    Enchanting     = 333,
    Skinning       = 393,
    Jewelcrafting  = 755,
    Inscription    = 773,
}

Env.professionNames = {}

-- Map localized profession names -> english key expected by the sim.
-- (Uses profession spell IDs that exist in 3.3.5a and later.)
local professionSpellIDs = {
    Blacksmithing  = 2018,
    Leatherworking = 2108,
    Alchemy        = 2259,
    Herbalism      = 2366,
    Mining         = 2575,
    Tailoring      = 3908,
    Engineering    = 4036,
    Enchanting     = 7411,
    Skinning       = 8613,
    Jewelcrafting  = 25229,
    Inscription    = 45357,
}

for engName, spellID in pairs(professionSpellIDs) do
    local localizedName = GetSpellInfo(spellID)
    if localizedName then
        Env.professionNames[localizedName] = { engName = engName }
    end
end
end

local statToStatId = {
    str = 1,
    strength = 1,
    agi = 2,
    agility = 2,
    stam = 3,
    stm = 3,
    stamina = 3,
    int = 4,
    intellect = 4,
    spi = 5,
    spirit = 5,
}

---Determine if an item should be exported on bag item export.
-- TODO(Riotdog-GehennasEU): Is this sufficient? This seems to be what simc uses:
-- https://github.com/simulationcraft/simc-addon/blob/master/core.lua
-- Except we don't need the artifact check for wotlk classic.
---@param itemLink string See https://wowpedia.fandom.com/wiki/ItemLink
---@return boolean exportItem true if item should be exported
function Env.TreatItemAsPossibleUpgrade(itemLink)
    if not IsEquippableItem(itemLink) then return false end

    local name, link, quality, itemLevel = GetItemInfo(itemLink)
    if not quality or not itemLevel then
        -- Item data might not be cached yet, be conservative and export it.
        return true
    end

    -- Item quality values (3.3.5a): 0 poor, 1 common, 2 uncommon, 3 rare, 4 epic, 5 legendary, 6 artifact, 7 heirloom
    if Env.IS_CLASSIC_ERA then
        local minIlvl = UnitLevel("player") - 15
        if itemLevel <= minIlvl or quality < 2 then
            return false
        end
    elseif Env.IS_CLASSIC_WRATH or Env.IS_CLASSIC_CATA then
        -- Ignore low ilvl / low quality items
        if itemLevel <= 112 or quality < 3 then
            return false
        end
    end

    return true
end

---Check if stat1 is bigger than stat2.
---Accepts short (agi) or full stat names (agility)
---@param stat1 string
---@param stat2 string
---@return boolean
function Env.StatBiggerThanStat(stat1, stat2)
    local statId1 = statToStatId[stat1:lower()]
    local statId2 = statToStatId[stat2:lower()]
    assert(statId1 and statId2, "Invalid stat identifiers provided!")
    return select(2, UnitStat("player", statId1)) > select(2, UnitStat("player", statId2))
end

-- Some runes learn multiple spells, i.e. the learnedAbilitySpellIDs array of the
-- rune data returned by C_Engraving.GetRuneForEquipmentSlot and C_Engraving.GetRuneForInventorySlot
-- has multiple entries. The sim uses one of those Ids to indentify runes.
-- Map the first spell Id to the expected spell Id for runes that do not have it at position 1.
local runeSpellRemap = {
    [407993] = 407995, -- Mangle: The bear version is expected.
}

-- Ring Runes don't provide a Spell ID like other runes do. We have to convert the Enchant ID back to the Spell ID manually.
-- Ordered by spell name
local enchantmentIDToSpellID = {
    [7514] = 442893, -- Arcane Specialization
    [7508] = 442876, -- Axe Specialization
    [7510] = 442887, -- Dagger Specialization
    [7555] = 459312, -- Defense Specialization
    [7520] = 453622, -- Feral Combat Specialization
    [7515] = 442894, -- Fire Specialization
    [7511] = 442890, -- Fist Weapon Specialization
    [7516] = 442895, -- Frost Specialization
    [7519] = 442898, -- Holy Specialization
    [7509] = 442881, -- Mace Specialization
    [7517] = 442896, -- Nature Specialization
    [7513] = 442892, -- Pole Weapon Specialization
    [7512] = 442891, -- Ranged Weapon Specialization
    [7518] = 442897, -- Shadow Specialization
    [7507] = 442813, -- Sword Specialization
}

---Get rune spell from an item in a slot, if item has a rune engraved.
---@param slotId integer
---@param bagId integer|nil If not nil check bag items instead of equipped items.
---@return integer|nil abilitySpellId The first spell id granted by the rune, or nil if no rune engraved.
function Env.GetEngravedRuneSpell(slotId, bagId)
    if not _G.C_Engraving or not C_Engraving.GetNumRunesKnown then return nil end
    -- After first login the whole engraving stuff may not be loaded yet!
    -- GetNumRunesKnown will return 0 for maximum runes available in that case.
    if select(2, C_Engraving.GetNumRunesKnown()) == 0 then
        LoadAddOn("Blizzard_EngravingUI")
        C_Engraving.RefreshRunesList()
    end

    -- The shoulder "runes" are special and don't use the C_Engraving API
    -- Instead they override a special spell "Soul Engraving" (1219955)
    if bagId == nil then
        if slotId == INVSLOT_SHOULDER then
            return FindSpellOverrideByID(1219955)
        end
    else
        local itemLocation = ItemLocation:CreateFromBagAndSlot(bagId, slotId)
        local inventoryType = C_Item.GetItemInventoryType(itemLocation)
        if inventoryType == Enum.InventoryType.IndexShoulderType then
            return Env.GetSoulEngravingSpellID(slotId, bagId)
        end
    end

    local runeData
    if bagId == nil then
        runeData = C_Engraving.GetRuneForEquipmentSlot(slotId)
    else
        runeData = C_Engraving.GetRuneForInventorySlot(bagId, slotId)
    end

    if runeData then
        local firstSpellId = runeData.learnedAbilitySpellIDs[1]
        if firstSpellId == nil then
            -- Fall back to re-mapping the enchant ID.
            -- Should only apply to ring specializations for now.
            return enchantmentIDToSpellID[runeData.itemEnchantmentID]
        else
            -- All non-ring runes should have a Spell ID
            if runeSpellRemap[firstSpellId] then
                return runeSpellRemap[firstSpellId]
            end
            return firstSpellId
        end
    end
end

---Counts spent talent points per tree.
---@param isInspect boolean If true use inspect target.
---@return table pointsPerTreeTable { tree1Count, tree2Count, tree3Count }
local function CountSpentTalentsPerTree(isInspect)
    local trees = {}

    for tab = 1, GetNumTalentTabs(isInspect) do
        trees[tab] = 0
        for i = 1, GetNumTalents(tab, isInspect) do
            local _, _, _, _, currentRank = GetTalentInfo(tab, i, isInspect)
            trees[tab] = trees[tab] + currentRank
        end
    end

    return trees
end

local specializations = {}

---Try to find spec. Returns empty strings if spec could not be found.
---@param unit string "player" or the inspected unit
---@return string specName The name of the spec, e.g. "feral".
---@return string specUrl The URL part of the spec, e.g. "feral_druid"
function Env.GetSpec(unit)
    local playerClass = select(2, UnitClass(unit))

    if specializations[playerClass] then
        if Env.IS_CLASSIC_MISTS then
            local activeSpec, specId
            if unit =="player" then
                activeSpec = C_SpecializationInfo.GetSpecialization()
                specId, _ = C_SpecializationInfo.GetSpecializationInfo(activeSpec)
            else
                specId = GetInspectSpecialization(unit)
            end
            for _, specData in pairs(specializations[playerClass]) do
                if specData.specId == specId then
                    return specData.spec, specData.url
                end
            end
        else
            local spentTalentPoints
            spentTalentPoints = CountSpentTalentsPerTree(unit == "target")
            for _, specData in pairs(specializations[playerClass]) do
                if specData.isCurrentSpec(spentTalentPoints) then
                    return specData.spec, specData.url
                end
            end
        end
    end

    return "", ""
end

---Add spec to detection list.
---@param playerClass string
---@param spec string The name of the spec, e.g. "feral".
---@param url string The URL part of the spec, e.g. "feral_druid"
---@param checkFunc fun(spentTanlents:number[]):boolean
---@param specId integer|nil The SpecializationID of the spec
function Env.AddSpec(playerClass, spec, url, checkFunc, specId)
    playerClass = playerClass:upper()
    specializations[playerClass] = specializations[playerClass] or {}
    table.insert(specializations[playerClass], {
        spec = spec,
        url = url,
        isCurrentSpec = checkFunc,
        specId = specId,
    })
end

CreateFrame("GameTooltip", "WSEScanningTooltip", nil, "GameTooltipTemplate")
WSEScanningTooltip:SetOwner(WorldFrame, "ANCHOR_NONE")

local baseItemLink = "item:9333:"
if _G.C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(baseItemLink) end

---@return table<integer, string>
local function GetBaseItemText()
    WSEScanningTooltip:ClearLines()
    WSEScanningTooltip:SetHyperlink(baseItemLink)
    local regions = { WSEScanningTooltip:GetRegions() }

    local itemText = {}

    for i = 1, #regions do
        local region = regions[i]
        if region and region:GetObjectType() == "FontString" then
            local text = region:GetText()
            if text then
                itemText[i] = text
            end
        end
    end

    return itemText
end

local baseItemText

---Get the localized text of a given enchantID as it will appear in an tooltip
---@param enchantID integer
---@return string
function Env.GetEnchantText(enchantID)
    if not baseItemText then
        baseItemText = GetBaseItemText()
    end

    WSEScanningTooltip:ClearLines()
    WSEScanningTooltip:SetHyperlink(baseItemLink .. enchantID)
    local regions = { WSEScanningTooltip:GetRegions() }

    for i = 1, #regions do
        local region = regions[i]
        if region and region:GetObjectType() == "FontString" then
            local text = region:GetText()
            if text and baseItemText[i] ~= text then
                return text
            end
        end
    end

    return ""
end

---Parse current item upgrade level from item tooltip.
---@param unit string
---@param itemSlot integer
---@return integer
function Env.GetItemUpgradeLevel(unit, itemSlot)
    WSEScanningTooltip:ClearLines()
    WSEScanningTooltip:SetInventoryItem(unit, itemSlot)
    local regions = { WSEScanningTooltip:GetRegions() }

    for i = 1, #regions do
        local region = regions[i]
        if region and region:GetObjectType() == "FontString" then
            local text = region:GetText()
            if text and text:find(ITEM_UPGRADE_TOOLTIP_FORMAT) then
                local pattern, _ = ITEM_UPGRADE_TOOLTIP_FORMAT:gsub("%%d","%(%%d%)")
                local _, _, curLevel, maxLevel = text:find(pattern)
                return tonumber(curLevel)
            end
        end
    end
    return -1
end


---Parse hand tinker from item tooltip.
---@param unit string
---@return integer
function Env.GetHandTinker(unit)
    WSEScanningTooltip:ClearLines()
    WSEScanningTooltip:SetInventoryItem(unit, INVSLOT_HAND)
    local regions = { WSEScanningTooltip:GetRegions() }

    local use_localized = ITEM_SPELL_TRIGGER_ONUSE
    local cooldown_m_localized = ITEM_COOLDOWN_TOTAL_MIN -- korean locale uses another string : ITEM_COOLDOWN_TOTAL
    local cooldown_s_localized = ITEM_COOLDOWN_TOTAL_SEC

    for i = 1, #regions do
        local region = regions[i]
        if region and region:GetObjectType() == "FontString" then
            local text = region:GetText()
            -- some client have wierd character as separator, so hopefuly .?.? picks them all
            if text and text:find(use_localized..".+1.?.?920.+") then
                return 4898 -- Synapse Srping
            end
            if text and text:find(use_localized..".+2.?.?880.+") then
                return 4697 -- Phase Fingers
            end
            if text and text:find(use_localized..".+42.?.?000.+63.?.?000.+") then
                return 4698 -- Incendiary Fireworks Launcher
            end
        end
    end
    return 0
end
