# WowSimsExporter Classic SoD

## [v3.1.6](https://github.com/wowsims/exporter/tree/v3.1.6) (2026-01-04)
[Full Changelog](https://github.com/wowsims/exporter/compare/v3.1.5...v3.1.6) [Previous Releases](https://github.com/wowsims/exporter/releases)

- Merge pull request #52 from Polynomix/korean-locale  
    synapse korean locale  
- more url ref changes  
- changed site url  
- changed synapse parsing for korean locale  
- toc bump  
